public class Conta {
    int numero;
    String titular;
    double saldo;

    private  static  int totalDecontas;


    //	construtor
    Conta (String titular){
        this.titular = titular;
        Conta.totalDecontas = Conta.totalDecontas + 1;
    }

    public static  int getTotalDecontas(){
        return Conta.totalDecontas;
    }




}
