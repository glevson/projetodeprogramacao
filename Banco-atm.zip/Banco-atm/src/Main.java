//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Conta c2 = new  Conta("Francisco");

        Conta c3 = new  Conta("Glevson");

        Conta c4 = new Conta("Vanessa");

        int total = Conta.getTotalDecontas();
        System.out.println("Total de contas do banco é:  " +total);

        System.out.println("Nome titular C02: "+ c2.titular);
        System.out.println("Nome titular C03: "+ c3.titular);

    }
}